import React from 'react';

const person = () => {
    return <p>This is {Math.floor(Math.random()*50)} test</p>
};

export default person;