import React, { Component } from 'react';
import './App.css';
import data from './firstreact.json';
import { Container,Grid, Image,Button} from 'semantic-ui-react';
import wifi from './assets/images/wifi.png';
import key from './assets/images/key.png';
import car from './assets/images/car.png';
import user from './assets/images/user.png';
import room1 from './assets/images/room1.png';
import room2 from './assets/images/room2.png';
import room3 from './assets/images/room3.png';
import room4 from './assets/images/room4.png';
import Test from './assets/CustomComp/CustomComp.js';

class App extends Component {
  render() {
    return (
      <Container>
       
        <Grid columns={4}>
    <Grid.Row>
      <Grid.Column>
        <Image src={wifi}/>
        <h1>{data.two[0].header1}</h1>
        <Image src={room1}/>
      </Grid.Column>
      <Grid.Column>
        <Image src={key} />
        <h1>{data.two[1].header1}</h1>
        <Image src={room2}/>
      </Grid.Column>
      <Grid.Column>
        <Image src={car} />
        <h1>{data.two[2].header1}</h1>
        <Image src={room3}/>
      </Grid.Column>
      <Grid.Column>
        <Image src={user} />
        <h1>{data.two[3].header1}</h1>
        <Image src={room4}/>
      </Grid.Column>
    </Grid.Row>
    </Grid>

      <Grid columns={2}>
    <Grid.Row>    
      <Grid.Column>
      <Grid columns={2}>
        <Grid.Row>
           <Grid.Column>
              <Image src={room1} width='500' height='300'/>
          </Grid.Column>
          <Grid.Column>
              <h2>{data.one[0].header}</h2>
              <p>{data.one[0].Desc}</p>
              <Button basic color='black'>Read More</Button>
        </Grid.Column>
      </Grid.Row>
      </Grid>
      </Grid.Column>
      <Grid.Column>
      <Grid columns={2}>
        <Grid.Row>
           <Grid.Column>
           <Image src={room2} width='500' height='300'/>
          </Grid.Column>
          <Grid.Column>
              <h2>{data.one[0].header}</h2>
              <p>{data.one[0].Desc}</p>
              <Button basic color='black'>Read More</Button>
        </Grid.Column>
      </Grid.Row>
      </Grid>
      </Grid.Column>
    </Grid.Row>
  </Grid>


  <Grid columns={2}>
    <Grid.Row>    
      <Grid.Column>
      <Grid columns={2}>
        <Grid.Row>
          <Grid.Column>
              <h2>{data.one[0].header}</h2>
              <p>{data.one[0].Desc}</p>
              <Button basic color='black'>Read More</Button>
         </Grid.Column>
         <Grid.Column>
              <Image src={room3} width='500' height='300'/>
          </Grid.Column>
      </Grid.Row>
      </Grid>
      </Grid.Column>
      <Grid.Column>
      <Grid columns={2}>
        <Grid.Row>
          <Grid.Column>
              <h2>{data.one[0].header}</h2>
              <p>{data.one[0].Desc}</p>
              <Button basic color='black'>Read More</Button>
        </Grid.Column>
        <Grid.Column>
           <Image src={room4} width='500' height='300'/>
          </Grid.Column>
      </Grid.Row>
      </Grid>
      </Grid.Column>
    </Grid.Row>
  </Grid>

   <Test/>
   <Test/>
   <Test/>
   <Test/>
   <Test/>
  </Container>
    );
  }
}

export default App;
